package net.minecraft.src;

public class NoiseGenerator {
	public final String a;
	public final ICommandListener b;

	public NoiseGenerator(String string1, ICommandListener iCommandListener2) {
		this.a = string1;
		this.b = iCommandListener2;
	}
}
