package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Packet0KeepAlive extends Packet {
	public void processPacket(NetHandler netHandler1) {
	}

	public void readPacketData(DataInputStream dataInputStream1) {
	}

	public void writePacket(DataOutputStream dataOutputStream1) {
	}

	public int getPacketSize() {
		return 0;
	}
}
