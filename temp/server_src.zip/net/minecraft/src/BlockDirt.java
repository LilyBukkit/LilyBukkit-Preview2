package net.minecraft.src;

public class BlockDirt extends Block {
	protected BlockDirt(int id, int blockIndex) {
		super(id, blockIndex, Material.grass);
	}
}
