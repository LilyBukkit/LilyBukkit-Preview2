package net.minecraft.src;

import java.util.Random;

public class ifC extends Block {
	private boolean a;

	public ifC(int i1, boolean z2) {
		super(i1, 6, Material.rock);
		if(!(this.a = z2)) {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		}

		this.setLightOpacity(255);
	}

	public int getBlockTextureFromSide(int i1) {
		return i1 <= 1 ? 6 : 5;
	}

	public boolean isOpaqueCube() {
		return this.a;
	}

	public void onNeighborBlockChange(World world, int x, int y, int z, int flag) {
		if(this == Block.stairSingle) {
			;
		}
	}

	public void onBlockAdded(World world1, int i2, int i3, int i4) {
		if(this != Block.stairSingle) {
			super.onBlockAdded(world1, i2, i3, i4);
		}

		if(world1.getBlockId(i2, i3 - 1, i4) == stairSingle.blockID) {
			world1.setBlockWithNotify(i2, i3, i4, 0);
			world1.setBlockWithNotify(i2, i3 - 1, i4, Block.stairDouble.blockID);
		}

	}

	public int idDropped(int i1, Random random2) {
		return Block.stairSingle.blockID;
	}

	public boolean shouldSideBeRendered(IBlockAccess blockAccess, int x, int y, int z, int side) {
		if(this != Block.stairSingle) {
			super.shouldSideBeRendered(blockAccess, x, y, z, side);
		}

		return side == 1 || super.shouldSideBeRendered(blockAccess, x, y, z, side) && (side == 0 || blockAccess.getBlockId(x, y, z) != this.blockID);
	}
}
