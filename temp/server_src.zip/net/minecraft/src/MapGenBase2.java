package net.minecraft.src;

public class MapGenBase2 extends MapGenBase {
	protected void recursiveGenerate(World world1, int i2, int i3, int i4, int i5, byte[] b6) {
		int i7 = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(40) + 1) + 1);
		if(this.rand.nextInt(15) != 0) {
			boolean z8 = false;
		}

	}
}
