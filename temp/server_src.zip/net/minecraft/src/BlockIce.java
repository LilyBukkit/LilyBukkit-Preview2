package net.minecraft.src;

import java.util.Random;

public class BlockIce extends BlockBreakable {
	public BlockIce(int id, int blockIndex) {
		super(id, blockIndex, Material.ice, false);
		this.slipperiness = 0.98F;
		this.setTickOnLoad(true);
	}

	public boolean shouldSideBeRendered(IBlockAccess blockAccess, int x, int y, int z, int side) {
		return super.shouldSideBeRendered(blockAccess, x, y, z, 1 - side);
	}

	public void onBlockRemoval(World world, int x, int y, int z) {
		Material material5 = world.getBlockMaterial(x, y - 1, z);
		if(material5.getIsSolid() || material5.getIsLiquid()) {
			world.setBlockWithNotify(x, y, z, Block.waterMoving.blockID);
		}

	}

	public int quantityDropped(Random random1) {
		return 0;
	}

	public void updateTick(World world1, int i2, int i3, int i4, Random random5) {
		if(world1.getSavedLightValue(EnumSkyBlock.Block, i2, i3, i4) > 11 - Block.lightOpacity[this.blockID]) {
			this.dropBlockAsItem(world1, i2, i3, i4, world1.getBlockMetadata(i2, i3, i4));
			world1.setBlockWithNotify(i2, i3, i4, Block.waterStill.blockID);
		}

	}
}
