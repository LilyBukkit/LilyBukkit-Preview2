package net.minecraft.src;

import java.io.IOException;
import java.util.logging.Logger;

import net.minecraft.server.MinecraftServer;

public class NetServerHandler extends NetHandler implements ICommandListener {
	public static Logger logger = Logger.getLogger("Minecraft");
	public NetworkManager netManager;
	public boolean connectionClosed = false;
	private MinecraftServer mcServer;
	private EntityPlayerMP playerEntity;
	private int playerInAirTime = 0;
	private double lastPosX;
	private double lastPosY;
	private double lastPosZ;
	private boolean hasMoved = true;

	public NetServerHandler(MinecraftServer minecraftServer1, NetworkManager networkManager2, EntityPlayerMP entityPlayerMP3) {
		this.mcServer = minecraftServer1;
		(this.netManager = networkManager2).setNetHandler(this);
		this.playerEntity = entityPlayerMP3;
		entityPlayerMP3.playerNetServerHandler = this;
	}

	public void handlePackets() throws IOException {
		this.netManager.processReadPackets();
		if(this.playerInAirTime++ % 20 == 0) {
			this.netManager.addToSendQueue(new Packet0KeepAlive());
		}

	}

	public void kickPlayer(String string1) {
		this.netManager.addToSendQueue(new Packet255KickDisconnect(string1));
		this.netManager.serverShutdown();
		this.mcServer.configManager.sendPacketToAllPlayers(this.playerEntity);
		this.connectionClosed = true;
	}

	public void handleFlying(Packet10Flying packet10Flying1) {
		double d2;
		if(!this.hasMoved) {
			d2 = packet10Flying1.yPosition - this.lastPosY;
			if(packet10Flying1.xPosition == this.lastPosX && d2 * d2 < 0.01D && packet10Flying1.zPosition == this.lastPosZ) {
				this.hasMoved = true;
			}
		}

		if(this.hasMoved) {
			this.lastPosX = this.playerEntity.posX;
			this.lastPosY = this.playerEntity.posY;
			this.lastPosZ = this.playerEntity.posZ;
			d2 = this.playerEntity.posX;
			double d4 = this.playerEntity.posY;
			double d6 = this.playerEntity.posZ;
			float f8 = this.playerEntity.rotationYaw;
			float f9 = this.playerEntity.rotationPitch;
			double d10;
			if(packet10Flying1.moving) {
				d2 = packet10Flying1.xPosition;
				d4 = packet10Flying1.yPosition;
				d6 = packet10Flying1.zPosition;
				d10 = packet10Flying1.stance - packet10Flying1.yPosition;
				if(d10 > 1.65D || d10 < 0.1D) {
					this.kickPlayer("Illegal stance");
					logger.warning(this.playerEntity.username + " had an illegal stance: " + d10);
				}

				this.playerEntity.managedPosY = packet10Flying1.stance;
			}

			if(packet10Flying1.rotating) {
				f8 = packet10Flying1.yaw;
				f9 = packet10Flying1.pitch;
			}

			this.playerEntity.onUpdateEntity();
			this.playerEntity.ySize = 0.0F;
			this.playerEntity.setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, f8, f9);
			d10 = d2 - this.playerEntity.posX;
			double d12 = d4 - this.playerEntity.posY;
			double d14 = d6 - this.playerEntity.posZ;
			boolean z17 = this.mcServer.worldMngr.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.boundingBox.copy().removeCoord(0.0625D, 0.0625D, 0.0625D)).size() == 0;
			this.playerEntity.moveEntity(d10, d12, d14);
			double d18 = d2 - this.playerEntity.posX;
			double d20 = d4 - this.playerEntity.posY;
			if(d20 > -0.5D || d20 < 0.5D) {
				d20 = 0.0D;
			}

			double d22 = d6 - this.playerEntity.posZ;
			double d24 = d18 * d18 + d20 * d20 + d22 * d22;
			boolean z26 = false;
			this.playerEntity.setPositionAndRotation(d2, d4, d6, f8, f9);
			boolean z27 = this.mcServer.worldMngr.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.boundingBox.copy().removeCoord(0.0625D, 0.0625D, 0.0625D)).size() == 0;
			if(z17 && (z26 || !z27)) {
				this.teleportTo(this.lastPosX, this.lastPosY, this.lastPosZ, f8, f9);
				return;
			}

			this.playerEntity.onGround = packet10Flying1.onGround;
			this.mcServer.configManager.serverUpdateMountedMovingPlayer(this.playerEntity);
		}

	}

	public void teleportTo(double d1, double d3, double d5, float f7, float f8) {
		this.hasMoved = false;
		this.lastPosX = d1;
		this.lastPosY = d3;
		this.lastPosZ = d5;
		this.playerEntity.setPositionAndRotation(d1, d3, d5, f7, f8);
		this.playerEntity.playerNetServerHandler.sendPacket(new Packet13PlayerLookMove(d1, d3 + 1.6200000047683716D, d3, d5, f7, f8, false));
	}

	public void handleBlockDig(Packet14BlockDig packet14BlockDig1) {
		WorldServer worldServer2 = this.mcServer.worldMngr;
		boolean z3 = this.mcServer.configManager.isOp(this.playerEntity.username);
		worldServer2.disableSpawnProtection = z3;
		boolean z5 = false;
		if(packet14BlockDig1.status == 0) {
			z5 = true;
		}

		if(packet14BlockDig1.status == 1) {
			z5 = true;
		}

		if(z5) {
			double d6 = this.playerEntity.posY;
			this.playerEntity.posY = this.playerEntity.managedPosY;
			MovingObjectPosition movingObjectPosition8 = this.playerEntity.rayTrace(4.0D, 1.0F);
			this.playerEntity.posY = d6;
			if(movingObjectPosition8 == null) {
				return;
			}

			if(movingObjectPosition8.blockX != packet14BlockDig1.xPosition || movingObjectPosition8.blockY != packet14BlockDig1.yPosition || movingObjectPosition8.blockZ != packet14BlockDig1.zPosition || movingObjectPosition8.sideHit != packet14BlockDig1.face) {
				return;
			}
		}

		int i18 = packet14BlockDig1.xPosition;
		int i7 = packet14BlockDig1.yPosition;
		int i19 = packet14BlockDig1.zPosition;
		int i9 = packet14BlockDig1.face;
		int i10 = (int)MathHelper.abs((float)(i18 - this.mcServer.worldMngr.spawnX));
		int i11 = (int)MathHelper.abs((float)(i19 - this.mcServer.worldMngr.spawnZ));
		if(i10 > i11) {
			i11 = i10;
		}

		if(packet14BlockDig1.status == 0) {
			if(i11 > 16 || z3) {
				this.playerEntity.theItemInWorldManager.onBlockClicked(i18, i7, i19);
			}
		} else if(packet14BlockDig1.status == 2) {
			this.playerEntity.theItemInWorldManager.blockRemoving();
		} else if(packet14BlockDig1.status == 1) {
			if(i11 > 16 || z3) {
				this.playerEntity.theItemInWorldManager.updateBlockRemoving(i18, i7, i19, i9);
			}
		} else if(packet14BlockDig1.status == 3) {
			double d12 = this.playerEntity.posX - ((double)i18 + 0.5D);
			double d14 = this.playerEntity.posY - ((double)i7 + 0.5D);
			double d16 = this.playerEntity.posZ - ((double)i19 + 0.5D);
			if(d12 * d12 + d14 * d14 + d16 * d16 < 256.0D) {
				this.playerEntity.playerNetServerHandler.sendPacket(new Packet53BlockChange(i18, i7, i19, this.mcServer.worldMngr));
			}
		}

		this.mcServer.worldMngr.disableSpawnProtection = false;
	}

	public void handlePlace(Packet15Place packet15Place1) {
		WorldServer worldServer2 = this.mcServer.worldMngr;
		boolean z3 = this.mcServer.configManager.isOp(this.playerEntity.username);
		worldServer2.disableSpawnProtection = z3;
		int i5 = packet15Place1.xPosition;
		int i6 = packet15Place1.yPosition;
		int i7 = packet15Place1.zPosition;
		int i8 = packet15Place1.direction;
		int i9 = (int)MathHelper.abs((float)(i5 - this.mcServer.worldMngr.spawnX));
		int i10 = (int)MathHelper.abs((float)(i7 - this.mcServer.worldMngr.spawnZ));
		if(i9 > i10) {
			i10 = i9;
		}

		if(i10 > 16 || z3) {
			this.playerEntity.theItemInWorldManager.activeBlockOrUseItem(this.playerEntity, this.mcServer.worldMngr, new ItemStack(packet15Place1.id), i5, i6, i7, i8);
		}

		this.playerEntity.playerNetServerHandler.sendPacket(new Packet53BlockChange(i5, i6, i7, this.mcServer.worldMngr));
		this.mcServer.worldMngr.disableSpawnProtection = false;
	}

	public void handleErrorMessage(String string1) {
		logger.info(this.playerEntity.username + " lost connection: " + string1);
		this.mcServer.configManager.sendPacketToAllPlayers(this.playerEntity);
		this.connectionClosed = true;
	}

	public void registerPacket(Packet packet1) {
		logger.warning(this.getClass() + " wasn\'t prepared to deal with a " + packet1.getClass());
		this.kickPlayer("Protocol error, unexpected packet");
	}

	public void sendPacket(Packet packet1) {
		this.netManager.addToSendQueue(packet1);
	}

	public void handleBlockItemSwitch(Packet16BlockItemSwitch packet) {
		int i2 = packet.id;
		if(i2 == 0) {
			this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = null;
		} else {
			this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = new ItemStack(i2);
		}

		this.mcServer.entityTracker.sendPacketToTrackedPlayers(this.playerEntity, new Packet16BlockItemSwitch(this.playerEntity.entityID, i2));
	}

	public void handlePickupSpawn(Packet21PickupSpawn packet) {
		EntityItem entityItem2 = new EntityItem(this.mcServer.worldMngr, (double)packet.xPosition / 32.0D, (double)packet.yPosition / 32.0D, (double)packet.zPosition / 32.0D, new ItemStack(packet.itemID, packet.count));
		entityItem2.motionX = (double)packet.rotation / 128.0D;
		entityItem2.motionY = (double)packet.pitch / 128.0D;
		entityItem2.motionZ = (double)packet.roll / 128.0D;
		entityItem2.delayBeforeCanPickup = 10;
		this.mcServer.worldMngr.spawnEntityInWorld(entityItem2);
	}

	public void handleChat(Packet3Chat packet3Chat1) {
		String string2 = packet3Chat1.message;
		if(string2.length() > 100) {
			this.kickPlayer("Chat message too long");
		} else {
			String string3 = string2.trim();

			for(int i4 = 0; i4 < string3.length(); ++i4) {
				if(" !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1???\u00ae\u00ac???\u00ab\u00bb".indexOf(string3.charAt(i4)) < 0) {
					this.kickPlayer("Illegal characters in chat");
					return;
				}
			}

			if(string3.startsWith("/")) {
				this.handleSlashCommand(string3);
			} else {
				String string5 = "<" + this.playerEntity.username + "> " + string3;
				logger.info(string5);
				this.mcServer.configManager.sendPacketToPlayer(new Packet3Chat(string5));
			}

		}
	}

	private void handleSlashCommand(String string1) {
		if(string1.toLowerCase().startsWith("/me ")) {
			string1 = "* " + this.playerEntity.username + " " + string1.substring(string1.indexOf(" ")).trim();
			logger.info(string1);
			this.mcServer.configManager.sendPacketToPlayer(new Packet3Chat(string1));
		} else if(string1.toLowerCase().startsWith("/tell ")) {
			if(string1.split(" ").length >= 3) {
				string1 = string1.substring(string1.indexOf(" ")).trim();
				string1 = string1.substring(string1.indexOf(" ")).trim();
				string1 = "\u00a77" + this.playerEntity.username + " whispers " + string1;
				logger.info(string1);
				this.mcServer.configManager.sendPacketToPlayer(new Packet3Chat(string1));
			}
		} else if(string1.toLowerCase().equalsIgnoreCase("/home")) {
			logger.info(this.playerEntity.username + " returned home");
			this.teleportTo((double)this.mcServer.worldMngr.spawnX + 0.5D, (double)this.mcServer.worldMngr.getTopSolidOrLiquidBlock(this.mcServer.worldMngr.spawnX, this.mcServer.worldMngr.spawnZ) + 1.5D, (double)this.mcServer.worldMngr.spawnZ + 0.5D, 0.0F, 0.0F);
		} else {
			int i2;
			if(string1.toLowerCase().equalsIgnoreCase("/iron")) {
				if(MinecraftServer.playerList.containsKey(this.playerEntity.username)) {
					logger.info(this.playerEntity.username + " failed to iron!");
					this.sendPacket(new Packet3Chat("\u00a7cYou can\'t /iron again so soon!"));
				} else {
					MinecraftServer.playerList.put(this.playerEntity.username, 6000);
					logger.info(this.playerEntity.username + " ironed!");

					for(i2 = 0; i2 < 4; ++i2) {
						this.playerEntity.dropPlayerItem(new ItemStack(Item.ingotIron, 1));
					}
				}
			} else if(string1.toLowerCase().equalsIgnoreCase("/wood")) {
				if(MinecraftServer.playerList.containsKey(this.playerEntity.username)) {
					logger.info(this.playerEntity.username + " failed to wood!");
					this.sendPacket(new Packet3Chat("\u00a7cYou can\'t /wood again so soon!"));
				} else {
					MinecraftServer.playerList.put(this.playerEntity.username, 6000);
					logger.info(this.playerEntity.username + " wooded!");

					for(i2 = 0; i2 < 4; ++i2) {
						this.playerEntity.dropPlayerItem(new ItemStack(Block.sapling, 1));
					}
				}
			} else if(this.mcServer.configManager.isOp(this.playerEntity.username)) {
				String string3 = string1.substring(1);
				logger.info(this.playerEntity.username + " issued server command: " + string3);
				this.mcServer.addCommand(string3, this);
			} else {
				logger.info(this.playerEntity.username + " tried command: " + string1.substring(1));
			}
		}

	}

	public void handleArmAnimation(Packet18ArmAnimation packet) {
		if(packet.animate == 1) {
			this.playerEntity.swingItem();
		}

	}

	public void handleKickDisconnect(Packet255KickDisconnect packet255KickDisconnect1) {
		this.netManager.networkShutdown("Quitting");
	}

	public int getNumChunkDataPackets() {
		return this.netManager.getNumChunkDataPackets();
	}

	public void addHelpCommandMessage(String string1) {
		this.sendPacket(new Packet3Chat("\u00a77" + string1));
	}

	public String getUsername() {
		return this.playerEntity.username;
	}
}
